#include <iostream>
#include <vector>
#include "PolyNode.h"

using namespace std;

int main()
{
    menu menu1;
    menu1.display();
    cout << "Program terminated!" << endl;
    return 0;
}
